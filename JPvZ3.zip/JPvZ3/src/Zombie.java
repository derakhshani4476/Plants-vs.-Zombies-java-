
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hp
 */
public class Zombie {

    protected BufferedImage img;
    protected Image image;
    

    protected int locX;
    protected int locY;
    public int life, counter;
    public boolean zombieMove = true, stopedByAnother = false;
    protected int speed;
    protected int y;

    public Zombie() {
        Random rand = new Random();
        y = rand.nextInt(5);
        locX = 811;
        locY = y * 95 + 90;
        this.life = 11;
        zombieMove = true;
        speed = 1;
        try {
            img = ImageIO.read(new File("BasicZombie.png"));
        } catch (IOException e) {
        }
        image = new ImageIcon("inPlace.gif").getImage();

    }

    public Image getImage() {
        return image;
    }

    public BufferedImage getImg() {
        return img;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void move() {

        locX = (locX - speed);
//        ّبه ازای هر فریم زامبی پنج پیکسل جلو میرود
    }

}
