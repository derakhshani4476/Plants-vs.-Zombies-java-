import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * This class is an abstract class which is the superClass of all other plants
 * 
 * @author Tahmine
 */
public abstract class Plant {
    
    protected ArrayList<Bullet> bulletArr;
    protected BufferedImage img;
    protected int cost;
    protected int life;
    protected int preparingTime;
    protected int locX;
    protected int locY;
    protected long bornTime;
    protected int x = -1;
    protected int y = -1;
    protected long start;
    protected Sun sun;

    /**
     * Initialize location of a plant with the given parameters
     * 
     * @param xLoc x location of the plant in the screen
     * @param yLoc y location of the plant in the screen
     */
    public Plant(int xLoc, int yLoc) {
        locX = xLoc;
        locY = yLoc;
        bulletArr = new ArrayList<>();
    }
    
    public abstract Image getImage();
    
    public abstract int getXLoc();
    
    public abstract int getYLoc();
    
    public void shoot(){
        
    }
    
    public void produceSun() {
    }
    
}