
/**
 * * In The Name of Allah **
 */

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

/**
 * The window on which the rendering is performed. This structure uses the
 * modern BufferStrategy approach for double-buffering; actually, it performs
 * triple-buffering! For more information on BufferStrategy check out:
 * http://docs.oracle.com/javase/tutorial/extra/fullscreen/bufferstrategy.html
 * http://docs.oracle.com/javase/8/docs/api/java/awt/image/BufferStrategy.html
 *
 * @author Seyed Mohammad Ghaffarian
 */
public class GameFrame extends JFrame {

    /**/ public static final int GAME_HEIGHT = 627;                  // 720p game resolution
/**/ public static final int GAME_WIDTH = 4 * GAME_HEIGHT / 3 - 25;  // wide aspect ratio

    private BufferedImage bg;
    private BufferedImage peaBut;
    private BufferedImage peaButD;
    private BufferedImage icePeaBut;
    private BufferedImage icePeaButD;
    private BufferedImage walnutBut;
    private BufferedImage walnutButD;
    private BufferedImage sunflowerBut;
    private BufferedImage sunflowerButD;
    private BufferedImage cherryBut;
    private BufferedImage cherryButD;
    private BufferStrategy bufferStrategy;
    public static boolean end;

    public GameFrame(String title) {

        super(title);

        setResizable(false);

        setSize(GAME_WIDTH, GAME_HEIGHT);
        try {
            bg = ImageIO.read(new File("background3.jpg"));
            peaBut = ImageIO.read(new File("peaB.png"));
            peaButD = ImageIO.read(new File("peaBd.png"));

            icePeaBut = ImageIO.read(new File("icePeaB.png"));
            icePeaButD = ImageIO.read(new File("SnowButD.png"));

            sunflowerBut = ImageIO.read(new File("sunflowerBut.png"));
            sunflowerButD = ImageIO.read(new File("sunflowerbutD.png"));

            walnutBut = ImageIO.read(new File("wal.png"));
            walnutButD = ImageIO.read(new File("walD.png"));

            cherryBut = ImageIO.read(new File("cherryBut.png"));
            cherryButD = ImageIO.read(new File("cherryButD.png"));
        } catch (IOException e) {
        }
    }

    /**
     * This must be called once after the JFrame is shown:
     * frame.setVisible(true); and before any rendering is started.
     */
    public void initBufferStrategy() {
        // Triple-buffering
        createBufferStrategy(3);
        bufferStrategy = getBufferStrategy();
    }

    /**
     * Game rendering with triple-buffering using BufferStrategy.
     */
    public void render(GameState state) {
        // Get a new graphics context to render the current frame
        Graphics2D graphics = (Graphics2D) bufferStrategy.getDrawGraphics();
        try {
            // Do the rendering
            doRendering(graphics, state);
        } finally {
            // Dispose the graphics, because it is no more needed
            graphics.dispose();
        }
        // Display the buffer
        bufferStrategy.show();
    // Tell the system to do the drawing NOW;
        // otherwise it can take a few extra ms and will feel jerky!
        Toolkit.getDefaultToolkit().sync();
    }

    /**
     * Rendering all game elements based on the game state.
     */
    private void doRendering(Graphics2D g2d, GameState state) {

                // Draw all game elements according 
        //  to the game 'state' using 'g2d' ...
        //
        g2d.drawImage(bg, null, 0, 27);

        if (state.totalSun >= 50) {
            g2d.drawImage(sunflowerBut, null, 100, 33);
        } else {
            g2d.drawImage(sunflowerButD, null, 100, 33);
        }
        if (state.totalSun >= 100) {
            g2d.drawImage(peaBut, null, 160, 33);
        } else {
            g2d.drawImage(peaButD, null, 160, 33);
        }
        if (state.level >= 2) {
            if (state.totalSun >= 50) {
                g2d.drawImage(walnutBut, null, 220, 33);
            } else {
                g2d.drawImage(walnutButD, null, 220, 33);
            }
        }

        if (state.level >= 2) {
            if (state.totalSun >= 175) {
                g2d.drawImage(icePeaBut, null, 280, 33);
            } else {
                g2d.drawImage(icePeaButD, null, 280, 33);
            }
        }

        if (state.level >= 3) {
            if (state.totalSun >= 150 && state.level >= 3) {
                g2d.drawImage(cherryBut, null, 340, 33);
            } else {
                g2d.drawImage(cherryButD, null, 340, 33);
            }
        }
        g2d.setFont(new Font("Dialog", Font.PLAIN, 20));
        g2d.setColor(Color.BLACK);
        int strWidth = g2d.getFontMetrics().stringWidth(Integer.toString(state.getTotalSun()));
        int strHeight = g2d.getFontMetrics().getHeight();

        g2d.drawString(Integer.toString(state.getTotalSun()), (35 + ((40 - strWidth) / 2)), 105);
        g2d.setColor(Color.PINK);
        g2d.drawString(".", 35, 105);

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (state.getPlants()[i][j] != null) {
                    g2d.drawImage(state.getPlants()[i][j].getImage(), state.getPlants()[i][j].getXLoc(),
                            state.getPlants()[i][j].getYLoc(), null);
                    if (state.getPlants()[i][j] instanceof Sunflower && state.getPlants()[i][j].sun != null) {
                        g2d.drawImage(state.getPlants()[i][j].sun.getImg(), null, state.getPlants()[i][j].locX - 20,
                                state.getPlants()[i][j].locY + 20);
                    }
                }
            }
        }

        for (Zombie z : state.getZombieList()) {

            if (z instanceof ZombieWithHat) {
                g2d.drawImage(z.getImage(), z.locX, z.locY - 20, null);
            } else {
                if (z instanceof JumpingZombie) {
                    g2d.drawImage(z.getImg(), null, z.locX, z.locY);
//                    System.out.println(((JumpingZombie) z).locX+"      "+((JumpingZombie) z).locY);

                } else {
                    g2d.drawImage(z.getImage(), z.locX, z.locY, null);
                }
            }
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (state.getPlants()[i][j] != null && state.getPlants()[i][j] instanceof Pea) {
                    for (Bullet bullet : state.getPlants()[i][j].bulletArr) {
                        g2d.drawImage(bullet.getImg(), null, bullet.locX, bullet.locY);
                    }
                }
            }
        }

                if(state.wave) {
                    g2d.setFont(new Font("Dialog", Font.PLAIN, 40));
                    g2d.setColor(Color.RED);
                    strWidth = g2d.getFontMetrics().stringWidth("یک موج بزرگ از زامبی در راه است");
                    strHeight = g2d.getFontMetrics().getHeight();
                    g2d.drawString("یک موج بزرگ از زامبی در راه است", ((GAME_WIDTH - strWidth) / 2), 
                            (GAME_HEIGHT - strHeight) / 2);
                    if((System.currentTimeMillis() - state.waveStart) > 1500) {
                        state.wave = false;
                    }
        
                }
                
                if(state.levelChanged) {
                    g2d.setFont(new Font("Dialog", Font.PLAIN, 40));
                    g2d.setColor(Color.RED);
                    strHeight = g2d.getFontMetrics().getHeight();
                    switch(state.level) {
                        case 2 :
                            strWidth = g2d.getFontMetrics().stringWidth("مرحله دوم");
                            g2d.drawString("مرحله دوم", ((GAME_WIDTH - strWidth) / 2), 
                                    (GAME_HEIGHT - strHeight) / 2);
                            break;
                        case 3 :
                            strWidth = g2d.getFontMetrics().stringWidth("مرحله سوم");
                            g2d.drawString("مرحله سوم", ((GAME_WIDTH - strWidth) / 2), 
                                    (GAME_HEIGHT - strHeight) / 2);
                        case 4 :
                            strWidth = g2d.getFontMetrics().stringWidth("مرحله چهارم");
                            g2d.drawString("مرحله چهارم", ((GAME_WIDTH - strWidth) / 2), 
                                    (GAME_HEIGHT - strHeight) / 2);
                    }
                    
                    if((System.currentTimeMillis() - state.levelStart) > 1500) {
                        state.levelChanged = false;
                    }
        
                }
                
                if(GameState.gameOver) {
                    g2d.setFont(new Font("Dialog", Font.PLAIN, 40));
                    g2d.setColor(Color.RED);
                    strWidth = g2d.getFontMetrics().stringWidth("شما باختید");
                    strHeight = g2d.getFontMetrics().getHeight();
                    g2d.drawString("شما باختید", ((GAME_WIDTH - strWidth) / 2), 
                            (GAME_HEIGHT - strHeight) / 2);
//                    if((System.currentTimeMillis() - state.gameOverTime) > 1000) {
                        end = true;
//                    }
        
                }
                
                if(GameState.finished) {
                    g2d.setFont(new Font("Dialog", Font.PLAIN, 40));
                    g2d.setColor(Color.RED);
                    strWidth = g2d.getFontMetrics().stringWidth("بازی تمام شد");
                    strHeight = g2d.getFontMetrics().getHeight();
                    g2d.drawString("بازی تمام شد", ((GAME_WIDTH - strWidth) / 2), 
                            (GAME_HEIGHT - strHeight) / 2);
//                    if((System.currentTimeMillis() - state.gameOverTime) > 1000) {
                        end = true;
//                    }
        
                }
    }

}
