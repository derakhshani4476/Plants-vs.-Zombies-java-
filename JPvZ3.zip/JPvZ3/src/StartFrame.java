
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ASUS
 */
public class StartFrame extends JFrame {

    JButton play;
    JLabel name;
    JTextField type;

    public StartFrame() {
        super("زامبی ها");
        this.play = new JButton("PLAY");
        super.setLayout(null);
//        name = new JLabel("لطفا نام خود را تایپ کنید!!!");
        type=new JTextField();
    }

}
