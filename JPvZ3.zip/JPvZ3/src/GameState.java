
/**
 * * In The Name of Allah **
 */
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class holds the state of the game and all of its elements. This class
 * also handles user inputs, which affect the game state.
 *
 * @author Seyed Mohammad Ghaffarian
 */
public class GameState {

    public static boolean gameOver = false, finished = false;

    private MouseHandler mouseHandler;
    public int totalSun;
    private int selectedButton = -1;
    private Boolean planted = false;
    private int xMouse;
    private int yMouse;
    private Plant[][] plants;
    private ArrayList<Zombie> zombieList;
    private boolean[] zombieInRow;
    public int level = 1, produce = 4;
    private Iterator<Bullet> bullIter;
    private Iterator<Zombie> zombieIter;
    private Iterator<Plant> plantIter;
    public boolean levelChanged = false, wave = false;
    public long waveStart, levelStart;
    int waveCount1 = 0, waveCount2 = 0, waveCount3 = 0, waveCount4 = 0;

//        private ArrayList<Bullet> bulletList;
    private int frameCounter = 0;

    public GameState() {
        totalSun = 150;
        plants = new Plant[5][9];
        zombieList = new ArrayList<>();
        zombieInRow = new boolean[5];
        for (int i = 0; i < 5; i++) {
            zombieInRow[i] = false;
        }
        //
        // Initialize the game state and all elements ...
        //
//        keyHandler = new KeyHandler();
        mouseHandler = new MouseHandler();
    }

    /**
     * The method which updates the game state.
     */
    public void update() {
        gameOver();
        if (frameCounter == 0) {
            System.out.println("level=" + level);
        }
        int x;
        int y;
        int plantLocX, plantLocY;
        frameCounter++;

        stop();
        bomb();

        //Creating new zombies
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    for (Zombie z : zombieList) {
                        if (z instanceof JumpingZombie && z.locX == plants[i][j].locX + 5 && z.locY + 40 == plants[i][j].locY) {
                            ((JumpingZombie) z).jump = true;

                        }
                    }
                }
            }
        }

        if (frameCounter % 400 == 0) {
            Zombie z = new Zombie();
            zombieList.add(z);
            zombieInRow[(z.locY - 90) / 95] = true;
        }

        if (frameCounter % 600 == 0 && level >= 2) {
            
            ZombieWithHat wi = new ZombieWithHat();
            zombieList.add(wi);
            zombieInRow[(wi.locY - 90) / 95] = true;
        }
        if (frameCounter % 800 == 0 && level >= 3) {

            JumpingZombie ju = new JumpingZombie();
            zombieList.add(ju);
            zombieInRow[(ju.locY - 90) / 95] = true;

        }
        if (frameCounter % 1000 == 0 && level == 4) {
            ZombieWithGun with = new ZombieWithGun();
            zombieList.add(with);
            zombieInRow[(with.locY - 90) / 95] = true;

        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    if (plants[i][j] instanceof Sunflower) {
                        if ((System.currentTimeMillis() - plants[i][j].bornTime) > 13000) {
                            plants[i][j].produceSun();
                            plants[i][j].sun.bornTime = System.currentTimeMillis();
                            plants[i][j].bornTime = System.currentTimeMillis();
                        }
                        if (plants[i][j].sun != null) {

                            if ((System.currentTimeMillis() - plants[i][j].sun.bornTime) > 9000) {
                                plants[i][j].sun = null;
                            }
                            //suns disappear

                            if (Math.pow(xMouse - (plants[i][j].locX - 20 + 35), 2)
                                    + Math.pow(yMouse - (plants[i][j].locY + 20 + 35), 2) < 225) {
                                totalSun += plants[i][j].sun.getValue();
//                               
                                plants[i][j].sun = null;
                            }

                        }

                    }
                    if (plants[i][j] instanceof Pea) {
                        bullIter = plants[i][j].bulletArr.iterator();
                        while (bullIter.hasNext()) {
                            Bullet b = bullIter.next();
                            b.move();
                            if (b.locX > 811) {
                                bullIter.remove();
                            }
                        }
                    }
                }
            }
        }

        //planting new plants
        if (planted) {
            x = (xMouse - 40) / 85;
            y = (yMouse - 130) / 95;
            x = Math.max(x, 0);
            x = Math.min(x, 8);
            y = Math.max(y, 0);
            y = Math.min(y, 4);
            plantLocX = 40 + x * 85;
            plantLocY = 130 + y * 95;
            if (selectedButton == 0) {
                plants[y][x] = new Sunflower(plantLocX, plantLocY);
                plants[y][x].bornTime = System.currentTimeMillis();
                totalSun -= 50;
            }
            if (selectedButton == 1) {
                plants[y][x] = new PeaShooter(plantLocX, plantLocY);
                totalSun -= 100;
            }
            if (selectedButton == 2) {
                plants[y][x] = new Walnut(plantLocX, plantLocY);
                totalSun -= 50;
            }
            if (selectedButton == 3) {
                plants[y][x] = new SnowPea(plantLocX, plantLocY);
                totalSun -= 175;
            }
            if (selectedButton == 4) {
                plantLocX -= 100;
                plantLocY -= 55;
                plants[y][x] = new CherryBomb(plantLocX, plantLocY);
                totalSun -= 150;
            }
            plants[y][x].x = x;
            plants[y][x].y = y;

            selectedButton = -1;
            planted = false;
        }

        zombieIter = zombieList.iterator();

        while (zombieIter.hasNext()) {
            Zombie z = zombieIter.next();
            if ((!(z instanceof JumpingZombie)) || (z instanceof JumpingZombie && !((JumpingZombie) z).jump) || (z instanceof JumpingZombie && ((JumpingZombie) z).jump && !((JumpingZombie) z).allowed)) {
//                System.out.println("ooooooooooomadam");

                if (z.zombieMove && frameCounter % 4 == 0 && z.counter == 0) {
                    z.move();
                }
                if (z.zombieMove && z.counter != 0 && frameCounter % 40 == 0) {
                    z.move();
                    z.counter--;
                }
            } else {

                ((JumpingZombie) z).jump();

            }

            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 9; j++) {
                    if (plants[i][j] != null) {

                        if (plants[i][j] instanceof Pea) {

                            //Move the Bullets
                            bullIter = plants[i][j].bulletArr.iterator();

                            while (bullIter.hasNext()) {
                                Bullet b = bullIter.next();

                                if (b.locX - 200 == z.locX - 150 && b.locY - 4 == z.locY + 40) {

                                    z.life--;
                                    if (b instanceof SnowBullet) {
                                        z.counter = 90;
                                    }
                                    if (z.life == 0) {
                                        int diedY = z.y;
                                        zombieIter.remove();
                                        zombieInRow[diedY] = false;
                                        for (Zombie zom : zombieList) {
                                            if (zom.y == diedY) {
                                                zombieInRow[diedY] = true;
                                            }
                                        }
                                    }
                                    bullIter.remove();

                                }

                            }

                        }
                        plantLose(z, plants[i][j]);
                        if (plants[i][j].life == 0) {
                            z.zombieMove = true;
                        }

                    }
                }
            }
        }
        //Remove the palnts with 0 life.
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    if (plants[i][j].life == 0) {
                        plants[i][j] = null;
                    }
                }
            }
        }

        //Shoot bullets
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {

                    if (zombieInRow[i] && frameCounter % 50 == 0 && plants[i][j] instanceof Pea) {
                        plants[i][j].shoot();
                    }
                }
            }
        }

        if (level == 1 && frameCounter >= 2000 && frameCounter < 2600) {
            if (frameCounter % 50 == 0) {

            }
            groupZombie1();
            
            if(waveCount1 == 0) {
            wave = true;
            waveStart = System.currentTimeMillis();
            waveCount1++;
            }
        }
        if (level == 1 && frameCounter >= 2600) {
            removeAllBullet();
            removeAllZombies();
            removeAllPlants();
            level++;
            levelChanged = true;
            levelStart = System.currentTimeMillis();
            totalSun = totalSun + 150;
            frameCounter = 0;

        }
        if (level == 2 && frameCounter >= 2000 && frameCounter < 2600) {
            groupZombie2();
           if(waveCount2 == 0) {
            wave = true;
            waveStart = System.currentTimeMillis();
            waveCount2++;
            }
        }
        if (level == 2 && frameCounter >= 2600) {
            removeAllBullet();
            removeAllZombies();
            removeAllPlants();
            level++;
            levelChanged = true;
            levelStart = System.currentTimeMillis();
            totalSun = totalSun + 150;
            frameCounter = 0;
        }
        if (level == 3 && frameCounter >= 2000 && frameCounter < 2600) {
            groupZombie3();
            if(waveCount3 == 0) {
            wave = true;
            waveStart = System.currentTimeMillis();
            waveCount3++;
            }
        }
        if (level == 3 && frameCounter >= 2600) {
            removeAllBullet();
            removeAllZombies();
            removeAllPlants();
            level++;
            levelChanged = true;
            levelStart = System.currentTimeMillis();
            totalSun = totalSun + 150;
            frameCounter = 0;
        }
        if (level == 4 && frameCounter >= 2000 && frameCounter < 2600) {
            groupZombie4();
            wave = true;
            waveStart = System.currentTimeMillis();
            if(waveCount4 == 0) {
            wave = true;
            waveStart = System.currentTimeMillis();
            waveCount4++;
            }

        }
        if (level == 4 && frameCounter >= 2600) {
            removeAllBullet();
            removeAllZombies();
            removeAllPlants();
            frameCounter = 0;
            finished = true;
        }
        xMouse = -1;
        yMouse = -1;
    }

    public void stop() {

        for (Zombie z : zombieList) {
            if (z.stopedByAnother) {
                z.zombieMove = true;
                z.stopedByAnother = false;
            }
        }

        for (Zombie x : zombieList) {
            for (Zombie y : zombieList) {
                if (!x.zombieMove && y.zombieMove && x.locX + 40 == y.locX && x.locY == y.locY) {
                    y.zombieMove = false;
                    y.stopedByAnother = true;
                }
                if (x.counter > 0 && x.locX + 40 == y.locX && x.locY == y.locY) {
                    y.zombieMove = false;
                    y.stopedByAnother = true;
                }
            }
        }
    }

    public void bomb() {

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    if (plants[i][j] instanceof CherryBomb) {
                        ((CherryBomb) plants[i][j]).explodeTime++;
                        if (((CherryBomb) plants[i][j]).explodeTime == 25) {

                            zombieIter = zombieList.iterator();
                            while (zombieIter.hasNext()) {
                                Zombie z = zombieIter.next();
                                if (z.locX - plants[i][j].locX >= 0 && z.locY - plants[i][j].locY >= 0) {
                                    if ((z.locX - plants[i][j].locX < 300 && z.locY - plants[i][j].locY < 300)) {

                                        zombieIter.remove();

                                    }
                                }
                                if (z.locX - plants[i][j].locX < 0 && z.locY - plants[i][j].locY < 0) {
                                    if (plants[i][j].locX - z.locX < 300 && plants[i][j].locY - z.locY < 300) {

                                        zombieIter.remove();
                                    }
                                }

                            }
                            plants[i][j] = null;
                        }

                    }
                }
            }
        }
    }

    public void removeAllBullet() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    if (plants[i][j] instanceof Pea) {
                        bullIter = plants[i][j].bulletArr.iterator();
                        while (bullIter.hasNext()) {
                            Bullet b = bullIter.next();
                            bullIter.remove();
                        }
                    }
                }
            }
        }
    }

    public void removeAllZombies() {
        zombieIter = zombieList.iterator();
        while (zombieIter.hasNext()) {
            Zombie z = zombieIter.next();
            zombieIter.remove();

        }
    }

    public void removeAllPlants() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++) {
                if (plants[i][j] != null) {
                    plants[i][j] = null;
                }
            }
        }
    }

    public ArrayList<Zombie> getZombieList() {
        return zombieList;
    }

    public void zombieLose(Zombie z, Bullet b) {
        if (b.locX - 50 == z.locX && b.locY - 4 == z.locY + 40) {

            z.life--;

            plants[b.y][b.x].bulletArr.remove(b);
        }
    }

    public void plantLose(Zombie z, Plant p) {
        if ((z.locX == p.locX && z.locY + 40 == p.locY && ((!(z instanceof JumpingZombie)) || (z instanceof JumpingZombie && !(((JumpingZombie) z).jump)) || (z instanceof JumpingZombie && (((JumpingZombie) z).jump) && !(((JumpingZombie) z).allowed))))) {
//            System.out.println("fateme");
            if (p.life != 0) {
                p.life--;
            }
            z.zombieMove = false;
        }
    }

    public void groupZombie1() {
        if (frameCounter % 100 == 0) {
            Zombie zo = new Zombie();
            zombieList.add(zo);
        }
    }

    public void groupZombie2() {
        if (frameCounter % 100 == 0) {
            Zombie zo = new Zombie();
            zombieList.add(zo);
        }
        if (frameCounter % 150 == 0) {
            ZombieWithHat with = new ZombieWithHat();
            zombieList.add(with);
        }
    }

    public void groupZombie3() {
        if (frameCounter % 100 == 0) {
            Zombie zo = new Zombie();
            zombieList.add(zo);
        }
        if (frameCounter % 150 == 0) {
            ZombieWithHat with = new ZombieWithHat();
            zombieList.add(with);
        }
        if (frameCounter % 200 == 0) {
            JumpingZombie with1 = new JumpingZombie();
            zombieList.add(with1);
        }
    }

    public void groupZombie4() {
        if (frameCounter % 100 == 0) {
            Zombie zo = new Zombie();
            zombieList.add(zo);
        }
        if (frameCounter % 150 == 0) {
            ZombieWithHat with = new ZombieWithHat();
            zombieList.add(with);
        }
        if (frameCounter % 200 == 0) {
            JumpingZombie with2 = new JumpingZombie();
            zombieList.add(with2);
        }
        if (frameCounter % 250 == 0) {
            ZombieWithGun with1 = new ZombieWithGun();
            zombieList.add(with1);
        }
    }

    public void gameOver() {
        for (Zombie z : zombieList) {
            if (z.locX == 0) {
                gameOver = true;
            }

        }

    }

    public int getTotalSun() {
        return totalSun;
    }

    public Plant[][] getPlants() {
        return plants;
    }

    public MouseListener getMouseListener() {
        return mouseHandler;
    }

    public MouseMotionListener getMouseMotionListener() {
        return mouseHandler;
    }

    /**
     * The mouse handler.
     */
    class MouseHandler implements MouseListener, MouseMotionListener {

//        @Override
        @Override
        public void mouseClicked(MouseEvent e) {
            xMouse = e.getX();
            yMouse = e.getY();
            if (yMouse < 100 && yMouse > 35) {
                if (xMouse < 150 && xMouse > 100 && totalSun >= 50) {
                    selectedButton = 0;
                }
                if (xMouse < 210 && xMouse > 160 && totalSun >= 100) {
                    selectedButton = 1;
                }
                if (xMouse < 270 && xMouse > 220 && totalSun >= 50) {
                    selectedButton = 2;
                }
                if (xMouse < 330 && xMouse > 280 && totalSun >= 175) {
                    selectedButton = 3;
                }
                if (xMouse < 390 && xMouse > 340 && totalSun >= 150) {
                    selectedButton = 4;
                }
            }
            if (xMouse < 765 && xMouse > 40 && yMouse < 595 && yMouse > 130 && selectedButton != -1) {
                planted = true;
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }

        @Override
        public void mouseDragged(MouseEvent e) {
        }

        @Override
        public void mouseMoved(MouseEvent e) {
        }
    }
}
