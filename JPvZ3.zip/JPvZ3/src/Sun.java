
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Class Sun which is produced by sunflower.
 *
 * @author Tahmine
 */
public class Sun {
    private int locX;
    private int locY;
    private final int value = 25;
    private final int disappearingTime = 10;
    private BufferedImage img;
    public long bornTime;
    
    /**
     * Initialize location and base image of a Sun
     *
     * @param xLoc X location of a Sun on the screen
     * @param yLoc Y location of a Sun on the screen
     */
    public Sun(int xLoc, int yLoc) {
        locX = xLoc;
        locY = yLoc;
        bornTime = 0;
        try {
            img = ImageIO.read(new File("sun.png"));
        } catch (IOException e) {
        }
    }

    public BufferedImage getImg() {
        return img;
    }

    public int getValue() {
        return value;
    }

    public void setBornTime(int bornTime) {
        this.bornTime = bornTime;
    }

    public long getBornTime() {
        return bornTime;
    }

    
    
    
    
    
    
    
}