
import java.awt.Image;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * An abstract class which is superClass of two other classes and a subClass of Plant class
 * Pea is a plant which shot bullets
 * 
 * @author Tahmine
 */
public abstract class Pea extends Plant {
    protected Image image;
    /**
     * Initialize location, life and the amount of time you should wait to be able to plant a pea again
     * 
     * @param xLoc x location of the pea in the screen
     * @param yLoc y location of the pea in the screen
     */
    public Pea(int xLoc, int yLoc) {
        super(xLoc, yLoc);
        life = 90;
        preparingTime = 5;
    }
    
    @Override
    public abstract void shoot();
}
