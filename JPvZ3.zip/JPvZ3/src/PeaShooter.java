
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * a subClass of Pea class
 *
 * @author Tahmine
 */
public class PeaShooter extends Pea{
    
    private Image image;
    /**
     * Initialize PeaShooter's location, base image, and cost
     *
     * @param xLoc x location of the PeaShooter in the screen
     * @param yLoc y location of the PeaShooter in the screen
     */
    public PeaShooter(int xLoc, int yLoc) {
        super(xLoc, yLoc);
        cost = 100;
        try {
            img = ImageIO.read(new File("pea.png"));
        } catch (IOException e) {
        }
        image = new ImageIcon("peaShooter.gif").getImage();
    }
    
    /**
     * Creates new PeaBullets.
     *
     */
    @Override
    public void shoot() {
        Bullet b = new PeaBullet(this.locX + 50, this.locY + 4);
        b.x = x;
        b.y = y;
        bulletArr.add(b);
    }
    
    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public int getXLoc() {
        return locX;
    }

    @Override
    public int getYLoc() {
        return locY;
    }
}
