
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * class of bullets which SnowPeas shoot
 *
 * @author Tahmine
 */
public class SnowBullet extends Bullet{
    
    /**
     * Initialize location and base image of a SnowBullet
     *
     * @param xLoc X location of a SnowBullet on the screen
     * @param yLoc Y location of a SnowBullet on the screen
     */
    public SnowBullet(int xLoc, int yLoc) {
        super(xLoc, yLoc);
        try {
            img = ImageIO.read(new File("frozenBullet.png"));
        } catch (IOException e) {
        }
    }

    @Override
    public BufferedImage getImg() {
        return img;
    }

    
    
    
}
