
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;


/**
 * CherryBomb class
 * CherryBomb explodes and kills the nearby zombies
 * 
 * @author Tahmine
 */
public class CherryBomb extends Plant{
    
    int explodeTime = 0;
    int destructionDomain;
    private Image image;
    
    /**
     * Initialize location, life, base image, amount of sun you must have (cost) and amount of time you must wait to be able 
     * to plant a CherryBomb again
     *
     * @param xloc x location of the CherryBomb in the screen
     * @param yloc y location of the CherryBomb in the screen
     */
    public CherryBomb(int xloc, int yloc) {
        super(xloc, yloc);
        cost = 150;
        life = 5;
        preparingTime = 35;
        try {
            img = ImageIO.read(new File("cherry.png"));
        } catch (IOException e) {
        }
        image = new ImageIcon("cherry2.gif").getImage();
    }

    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public int getXLoc() {
        return locX;
    }

    @Override
    public int getYLoc() {
        return locY;
    }
}
