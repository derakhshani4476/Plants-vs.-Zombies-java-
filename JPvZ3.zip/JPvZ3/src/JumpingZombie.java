
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class JumpingZombie extends Zombie {

    public int jumpCounter;
    public boolean jump, allowed;

    public void jump() {

        jumpCounter++;
        if (jumpCounter <= 62) {
            locX--;
            locY--;
        }
        if (jumpCounter > 62) {
            locX--;
            locY++;
            if (jumpCounter >= 124) {
                this.jump = false;
                this.allowed=false;
            
            }
        }

    }

    public JumpingZombie() {
        super();
        life=10;
//        System.out.println(locY);
        jump = false;
        this.allowed = true;
        jumpCounter = 0;
         try {

            img = ImageIO.read(new File("jump.png"));
        } catch (IOException e) {
        }
    }
      
}
