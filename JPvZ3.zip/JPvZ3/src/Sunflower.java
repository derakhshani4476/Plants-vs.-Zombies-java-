import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * a class which is a subClass of Plant class
 * Sunflower produce a sun every 23 sec
 *
 * @author Tahmine
 */
public class Sunflower extends Plant{
    private final int producingSunTime = 23;
    
    private Image image;
        
    
    /**
     * Initialize location, life, base image, amount of sun you must have (cost) and amount of time you must wait to be able to plant a 
     * sunflower again
     * 
     * @param xLoc x location of the sunflower in the screen
     * @param yLoc y location of the sunflower in the screen
     */
    public Sunflower(int xLoc, int yLoc) {
        super(xLoc, yLoc);
        cost = 50;
        life = 90;
        preparingTime = 7;
        bornTime = 0;
        
        try {
            img = ImageIO.read(new File("sunflower.png"));
        } catch (IOException e) {
        }
        image = new ImageIcon("SunFlower.gif").getImage();
  
    }
    
    /**
     * Creates a new sun.
     *
     */
    
    @Override
    public void produceSun() {
        sun = new Sun(this.locX, this.locY);
    }
    
    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public int getXLoc() {
        return locX;
    }

    @Override
    public int getYLoc() {
        return locY;
    }
}