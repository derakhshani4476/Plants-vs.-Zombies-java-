import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * a subClass of Pea class
 SnowPea shots icy bullets which slow down zombies
 *
 * @author Tahmine
 */
public class SnowPea extends Pea{
    
    /**
     * Initialize SnowPea's location, base image and cost
     *
     * @param xLoc x location of the SnowPea in the screen
     * @param yLoc y location of the SnowPea in the screen
     */
    public SnowPea(int xLoc, int yLoc) {
        super(xLoc, yLoc);
        cost = 175;
        try {
            img = ImageIO.read(new File("icePea.png"));
        } catch (IOException e) {
        }
        image = new ImageIcon("SnowPea.gif").getImage();
    }
    
    /**
     * Create new SnowBullets
     *
     */
    @Override
    public void shoot() {
        Bullet b = new SnowBullet(this.locX + 50, this.locY + 4);
        b.x = x;
        b.y = y;
        bulletArr.add(b);
        
    }

    @Override
    public Image getImage() {
        return image;
    }
    
    @Override
    public int getXLoc() {
        return locX;
    }

    @Override
    public int getYLoc() {
        return locY;
    }
}